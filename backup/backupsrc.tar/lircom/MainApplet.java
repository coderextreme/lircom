package lircom;

import java.applet.*;
public class MainApplet extends Applet {
	public void init() {
		MainWindow.main(new String [] { "lircom.Chat" });
	}
}
