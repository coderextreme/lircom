/*
 * Errors.java
 *
 * Created on February 13, 2005, 7:23 PM
 */

package lircom;

/**
 *
 * @author carlsonj
 */
public interface Errors {
	String K100 = "100";
	String V100 = "NO SUCH ID";
	//Integer K101 = new Integer(101);
	//String V101 = "ERROR IN PARSING SENDER AND RECIPIENT";   
}
