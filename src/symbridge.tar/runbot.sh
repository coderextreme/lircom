java -classpath martyr.jar:lircom.jar lircom.IRCClient afternet.config symbion.config
